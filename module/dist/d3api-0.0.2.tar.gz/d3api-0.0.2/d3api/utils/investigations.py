"""

questions, puzzles and wonderings

"""

'''

can I access the in-game character inventory from Python?
inventory is account bound? season bound? char bound?

 
where can I see the current seasons Kanais power items?


# https://www.d3planner.com/335087708
'''
